import back from "../assets/back.png";
import remove from "../assets/delete.png";
import logo from "../assets/logo.png";
import cart from "../assets/cart.png";
import favoritoFull from "../assets/favorito-full2.png";
import empty from "../assets/empty.png";
import endereco from "../assets/endereco.png";
import more from "../assets/expandir.png";
import dados from "../assets/meus-dados.png";
import logout from "../assets/logout.png";

export default {
    back, remove, logo, cart, favoritoFull, empty,
    endereco, more, dados, logout
};