export const styles = {
    textos: {
        fontSize: 50,
        color: "blue"
    },
    imagem: {
        width: 200,
        height: 200
    }
}


